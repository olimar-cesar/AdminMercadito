﻿namespace PruebaReporte1
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.AdminDataSet = new PruebaReporte1.AdminDataSet();
            this.usp_ReporteProductosBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.usp_ReporteProductosTableAdapter = new PruebaReporte1.AdminDataSetTableAdapters.usp_ReporteProductosTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.AdminDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.usp_ReporteProductosBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.usp_ReporteProductosBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "PruebaReporte1.Report1.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(635, 261);
            this.reportViewer1.TabIndex = 0;
            // 
            // AdminDataSet
            // 
            this.AdminDataSet.DataSetName = "AdminDataSet";
            this.AdminDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // usp_ReporteProductosBindingSource
            // 
            this.usp_ReporteProductosBindingSource.DataMember = "usp_ReporteProductos";
            this.usp_ReporteProductosBindingSource.DataSource = this.AdminDataSet;
            // 
            // usp_ReporteProductosTableAdapter
            // 
            this.usp_ReporteProductosTableAdapter.ClearBeforeFill = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(635, 261);
            this.Controls.Add(this.reportViewer1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.AdminDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.usp_ReporteProductosBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource usp_ReporteProductosBindingSource;
        private AdminDataSet AdminDataSet;
        private AdminDataSetTableAdapters.usp_ReporteProductosTableAdapter usp_ReporteProductosTableAdapter;
    }
}

