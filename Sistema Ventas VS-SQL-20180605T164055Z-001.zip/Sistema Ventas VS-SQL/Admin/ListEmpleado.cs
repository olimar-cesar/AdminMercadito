﻿using Admin.Clases;
using Admin.Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Admin
{
    public partial class ListEmpleado
    {
        public static DataSet GetEmpleado()
        {
            SqlParameter[] dbParams = new SqlParameter[]
                {
                };
            return DBHelper.ExecuteDataSet("usp_ListEmpleado_GetEmpleado", dbParams);
        }

        public static DataSet DeleteEmpleado(Empleado empleado)
        {
            SqlParameter[] dbParams = new SqlParameter[]
                {
                     DBHelper.MakeParam("@Id", SqlDbType.Int, 0, empleado.Id),
                };
            return DBHelper.ExecuteDataSet("usp_ListEmpleado_DeleteEmpleado", dbParams);
        }
    }
}