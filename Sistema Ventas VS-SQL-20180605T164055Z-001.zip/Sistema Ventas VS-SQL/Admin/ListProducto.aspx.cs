﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Admin.Clases;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;

namespace Admin
{
    public partial class ListProducto : paginaBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                try
                {
                    CargarGrilla();
                }
                catch (Exception ex)
                {

                    messageBox.ShowMessage(ex.Message);
                }

            }
        }

        private void CargarGrilla()
        {
            DataSet ds = ListProducto.GetProductos();
            gridproductos.DataSource = ds.Tables[0];
            gridproductos.DataBind();
        }

        protected void gridproductos_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName == "EditarProducto")
                {
                    string sProductoId = e.CommandArgument.ToString();
                    Response.Redirect("EditProducto.aspx?Id=" + sProductoId);
                }
                else if (e.CommandName == "EliminarProducto")
                {
                    Producto producto = new Producto();
                    producto.Id = Convert.ToInt32(e.CommandArgument.ToString());
                    ListProducto.DeleteProducto(producto);
                    CargarGrilla();
                }
            }
            catch (Exception ex)
            {
                messageBox.ShowMessage(ex.Message + ex.StackTrace);
            }
        }

        protected void btnExportar_Click(object sender, EventArgs e)
        {
            string Query = "exec usp_ReporteProductos";
            SqlCommand cmd = new SqlCommand(Query);
            DataTable dt;
            dt = GetData(cmd);
            GridView1.DataSource = dt;
            GridView1.DataBind();

            Response.ContentType = "application/pdf";
            Response.AddHeader("content-disposition", "attachment;filename=reporteProductos.pdf");
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            StringWriter sw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(sw);
            GridView1.AllowPaging = false;
            GridView1.DataBind();
            GridView1.RenderControl(hw);
            StringReader sr = new StringReader(sw.ToString());
            Document doc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
            HTMLWorker htmlParser = new HTMLWorker(doc);
            PdfWriter.GetInstance(doc, Response.OutputStream);
            doc.Open();
            htmlParser.Parse(sr);
            doc.Close();
            Response.Write(doc);
            Response.End();
            
        }


         
        private DataTable GetData(SqlCommand cmd)
        {
            DataTable dt = new DataTable();
            string con = ConfigurationManager.ConnectionStrings["AdminConnectionString"].ConnectionString;
            SqlConnection cn = new SqlConnection(con);
            SqlDataAdapter da = new SqlDataAdapter();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = cn;
            try
            {
                cn.Open();
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
                da.Dispose();
                cn.Dispose();
            }
        }
    }
}