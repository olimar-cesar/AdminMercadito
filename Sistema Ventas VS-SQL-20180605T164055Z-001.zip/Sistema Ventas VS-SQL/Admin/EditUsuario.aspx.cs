﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Admin.Clases;

namespace Admin
{
    public partial class EditUsuario : paginaBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                if (Request.QueryString["IdUser"] != null)
                {
                    int Usuarioid = Convert.ToInt32(Request.QueryString["IdUser"]);
                    CargarDatos(Usuarioid);
                }
                //txtDni.Attributes.Add("readonly", "true");
            }
        }

        private void CargarDatos(int Usuarioid)
        {
            Usuario usuario= new Usuario();
            usuario.Id = Convert.ToInt32(hdnUsuarioId.Value);
            usuario.Id = Usuarioid;            
            DataSet ds= EditUsuario.GetUsuario(usuario);
            DataRow dr = ds.Tables[0].Rows[0];

            txtUsuario.Text = dr["Usuario"].ToString();
            txtContrasena.Text = dr["Contraseña"].ToString();

            Empleado empleado = new Empleado();
            empleado.Id = Convert.ToInt32(hdnEmpleadoId.Value);
            DataSet da = AddEmpleado.GetEmpleado(empleado);
            DataRow dt = da.Tables[0].Rows[0];

            txtNombres.Text = dt["Nombres"].ToString();
            txtDni.Text = dt["Dni"].ToString();
            txtCargo.Text = dt["Cargo"].ToString();         

        }

        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                Usuario usuario = new Usuario();
                usuario.Id = Convert.ToInt32(hdnUsuarioId.Value);
                if (hdnUsuarioId.Value == "")
                {

                    Usuario user = new Usuario();
                    Empleado empleado = new Empleado();
                    empleado.Id = Convert.ToInt32(hdnEmpleadoId.Value);
                    user.UserName = txtUsuario.Text;
                    user.password = txtContrasena.Text;


                    if (EditUsuario.Insertar(user) > 0)
                    {
                        messageBox.ShowMessage("El Usuario se insertó correctamente!");
                    }
                }
                else
                {
                    Usuario user = new Usuario();
                    //user.Id = Convert.ToInt32(txtId.Text);
                    user.UserName = txtUsuario.Text;
                    user.password = txtContrasena.Text;

                    if (EditUsuario.Actualizar(user) > 0)
                    {
                       Response.Redirect("ListUsuario.aspx");
                    }
                }
            }
            catch (Exception ex)
            {
                
                  messageBox.ShowMessage(ex.Message+ex.StackTrace);
            }

        }

        protected void btnEmpleado_Click(object sender, EventArgs e)
        {
            Response.Redirect("ListUsuario.aspx");
        }
    }
}