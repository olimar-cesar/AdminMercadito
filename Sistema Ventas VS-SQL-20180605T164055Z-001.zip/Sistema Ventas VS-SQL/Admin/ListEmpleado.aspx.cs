﻿using Admin.Clases;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Admin
{
    public partial class ListEmpleado : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                try
                {
                    CargarGrilla();
                }
                catch (Exception ex)
                {

                    messageBox.ShowMessage(ex.Message);
                }

            }
        }

        private void CargarGrilla()
        {
            DataSet ds = ListEmpleado.GetEmpleado();
            gridEmpleados.DataSource = ds.Tables[0];
            gridEmpleados.DataBind();
        }

        protected void gridEmpleados_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName == "EditarEmpleado")
                {
                    string sEmpleadoId = e.CommandArgument.ToString();
                    Response.Redirect("EditEmpleado.aspx?Dni=" + sEmpleadoId);
                }
                else if (e.CommandName == "EliminarEmpleado")
                {
                    Empleado empleado = new Empleado();
                    empleado.Dni = Convert.ToInt32(e.CommandArgument.ToString());
                    ListEmpleado.DeleteEmpleado(empleado);
                    CargarGrilla();
                }
            }
            catch (Exception ex)
            {
                messageBox.ShowMessage(ex.Message + ex.StackTrace);
            }

        }

    }
}