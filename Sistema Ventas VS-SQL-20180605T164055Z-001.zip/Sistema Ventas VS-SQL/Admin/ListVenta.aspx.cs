﻿using Admin.Clases;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Admin
{
    public partial class ListVenta :paginaBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {

                    gridVentas.DataSource = ListVenta.GetVentas().Tables[0];
                    gridVentas.DataBind();

                }
            }
            catch (Exception ex)
            {
                
                messageBox.ShowMessage(ex.Message+ex.StackTrace);
            }
        }

        protected void gridVentas_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName == "EditarDetalles")
                {
                    string sVentaId = e.CommandArgument.ToString();
                    Response.Redirect("EditDetalleVenta.aspx?VentaId=" + sVentaId);
                }
                else if (e.CommandName == "EliminarVenta")
                {
                    Venta venta= new Venta();
                    string sVentaId = e.CommandArgument.ToString();
                    venta.Id = Convert.ToInt32(sVentaId);
                   int cantidadAfectada= ListVenta.DeleteVenta(venta);
                    if (cantidadAfectada == -1)
                    {
                        messageBox.ShowMessage("Esta venta aun tiene detalles, por lo tanto no se puede eliminar.");
                    }
                    else
                    {
                        messageBox.ShowMessage("La venta ha sido eliminada");
                        gridVentas.DataSource = ListVenta.GetVentas().Tables[0];
                        gridVentas.DataBind();
                    }
                }
            }
            catch (Exception ex)
            {
                messageBox.ShowMessage(ex.Message + ex.StackTrace);
            }
        }

        protected void btnExportar_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("C:\\PDF\\reporte.pdf", FileMode.Create);

            Document miDoc = new Document();
            PdfWriter escribirPDF = PdfWriter.GetInstance(miDoc, fs);

            miDoc.Open();

            Font fuente = FontFactory.GetFont("Verdana", 20, Font.BOLD, BaseColor.RED);
            Paragraph parrafo = new Paragraph("Prueba PDF", fuente);

            parrafo.Alignment = Element.ALIGN_CENTER;

            miDoc.Add(parrafo);

            miDoc.Close();
        }
    }
}